/* 
 * File:   Globals.h
 * Author: dennis
 *
 * Created on May 15, 2009, 10:02 AM
 */

#ifndef _GLOBALS_DENNIS_H
#define	_GLOBALS_DENNIS_H

#include <string>
using namespace std;

class Globals {
public:
   
    /////////////////////////GP estimator//////////////////////
    static int nrInter_ransac;
    static int numberOfPoints_reconAsObstacle;
};

#endif	/* _GLOBALS_DENNIS_H */
