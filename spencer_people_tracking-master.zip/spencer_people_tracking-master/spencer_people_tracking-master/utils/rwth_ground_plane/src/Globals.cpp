#include "Globals.h"
#include <string>

////////////////////////GP Estimator/////////////////////////
int Globals::nrInter_ransac;
int Globals::numberOfPoints_reconAsObstacle;
