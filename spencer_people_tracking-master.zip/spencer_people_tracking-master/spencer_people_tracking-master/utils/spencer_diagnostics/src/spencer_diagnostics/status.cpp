#include <spencer_diagnostics/status.h>

//boost::shared_ptr<ros::Publisher> spencer_diagnostics::Status::s_publisher;