This metapackage aggregates all subpackages of the SPENCER People Tracking Framework, and is mainly useful
when installing the packaged version of the framework.
